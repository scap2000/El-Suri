/**
 LIMITACI�N DE RESPONSABILIDAD - COPYRIGHT - [Espa�ol]
 ================================================================================
 El Suri - Entorno JAVA de Trabajo y Desarrollo para Gobierno Electr�nico
 ================================================================================

 Informaci�n del Proyecto:  http://elsuri.sourceforge.net

 Copyright (C) 2007-2010 por D'AMBROSIO MARCELO E CASSINA SANTIAGO SOC DE HECHO.
 D'AMBROSIO MARCELO E CASSINA SANTIAGO SOC DE HECHO es propiedad de
 Lic. Santiago Cassina (santiago@digitallsh.com.ar - scap2000@yahoo.com) y
 Marcelo D'Ambrosio (marcelo@digitallsh.com.ar - marcelodambrosio@gmail.com)
 http://www.digitallsh.com.ar

 Este programa es software libre: usted puede redistribuirlo y/o modificarlo
 bajo los t�rminos de la Licencia P�blica General GNU publicada
 por la Fundaci�n para el Software Libre, ya sea la versi�n 3
 de la Licencia, o (a su elecci�n) cualquier versi�n posterior.

 Este programa se distribuye con la esperanza de que sea �til, pero
 SIN GARANT�A ALGUNA; ni siquiera la garant�a impl�cita
 MERCANTIL o de APTITUD PARA UN PROP�SITO DETERMINADO.
 Consulte los detalles de la Licencia P�blica General GNU para obtener
 una informaci�n m�s detallada.

 Deber�a haber recibido una copia de la Licencia P�blica General GNU
 junto a este programa.
 En caso contrario, consulte <http://www.gnu.org/licenses/>.

 DISCLAIMER - COPYRIGHT - [English]
 =====================================================================================
 El Suri - JAVA Management & Development Environment for Electronic Government
 =====================================================================================

 Project Info:  http://elsuri.sourceforge.net

 Copyright (C) 2007-2010 by D'AMBROSIO MARCELO E CASSINA SANTIAGO SOC DE HECHO.
 D'AMBROSIO MARCELO E CASSINA SANTIAGO SOC DE HECHO is owned by
 Lic. Santiago Cassina (santiago@digitallsh.com.ar - scap2000@yahoo.com) and
 Marcelo D'Ambrosio (marcelo@digitallsh.com.ar - marcelodambrosio@gmail.com)
 http://www.digitallsh.com.ar

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/
/**
 * ElSuriDesktop.java
 *
 * */
package org.digitall.projects.elsuri.desktop;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

import org.digitall.common.systemmanager.interfaces.MonitorSelector;
import org.digitall.lib.common.OrganizationInfo;
import org.digitall.lib.environment.Environment;

public class ElSuriDesktop {

    private MainFrame frame;

    public ElSuriDesktop(GraphicsDevice[] devices) {
	Environment.mainClass = ElSuriDesktop.class;
	Environment.graphicsDevice = devices[0];
	if (devices.length > 1) {
	    if (!Environment.cfg.hasProperty("Screen")) {
		MonitorSelector monitorSelector = new MonitorSelector(devices);
		monitorSelector.show();
	    } else {
		Environment.graphicsDevice = devices[Integer.parseInt(Environment.cfg.getProperty("Screen"))];
	    }
	}
	frame = new MainFrame();
    }

    public static void main(String[] args) {
	// Get all system UI Defaults
	/*
	UIDefaults defaults = UIManager.getDefaults();
	Enumeration enume = defaults.keys();
	for (; enume.hasMoreElements(); ) {
	    // Get property name
	    Object key = enume.nextElement();
	    Object value = defaults.get(key);
	    System.out.println(key + ": " + value);
	}
	*/
	// Get all system properties
	/*
	Properties props = System.getProperties();
	// Enumerate all system properties
	Enumeration enume = props.propertyNames();
	for (; enume.hasMoreElements(); ) {
	    // Get property name
	    String propName = (String)enume.nextElement();
	    // Get property value
	    String propValue = (String)props.get(propName);
            System.out.println(propName + ": " + propValue);
	}
	*/
	Environment.mainClass = ElSuriDesktop.class;
	Boot.initGraphics();
	Environment.organization = "Municipalidad de DIGITALL";
	OrganizationInfo.setOrgName("Municipalidad de DIGITALL");
	OrganizationInfo.setTitle("MUNICIPALIDAD DE\nDIGITALL");
	OrganizationInfo.setShortName("Municipalidad de DIGITALL");
	OrganizationInfo.setDescription("Municipalidad de DIGITALL - Provincia DIGITALL");
        OrganizationInfo.setAddress("Dr. Univac I N� 1010 - Barrio Kernel - DIGITALL"); 
	OrganizationInfo.setShortAddress("Dr. Univac I N� 1010");
	OrganizationInfo.setCuit("99-99999999-9");
	OrganizationInfo.setZipCode("0000");
	OrganizationInfo.setLocation("DIGITALL");
	OrganizationInfo.setProvince("DIGITALL");
	OrganizationInfo.setCountry("Rep�blica Inform�tica");
        OrganizationInfo.setWebAddress("http://www.digitallsh.com.ar");
        OrganizationInfo.setPhoneNumber1("(0387) 4313379");
        OrganizationInfo.setPhoneNumber2("(0387) 4313379");
	Environment.defaultLocation = "DIGITALL (DIGITALL)";
	GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
	GraphicsDevice[] devices = env.getScreenDevices();
	new ElSuriDesktop(devices);
    }

}
