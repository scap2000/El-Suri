package org.digitall.projects.gea.oran;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

import org.digitall.common.systemmanager.interfaces.MonitorSelector;
import org.digitall.lib.common.OrganizationInfo;
import org.digitall.lib.environment.Environment;

public class GEAOran {

    private MainFrame frame;

    public GEAOran(GraphicsDevice[] devices) {
	Environment.graphicsDevice = devices[0];
	if (devices.length > 1) {
	    if (!Environment.cfg.hasProperty("Screen")) {
		MonitorSelector monitorSelector = new MonitorSelector(devices);
		monitorSelector.show();
	    } else {
		Environment.graphicsDevice = devices[Integer.parseInt(Environment.cfg.getProperty("Screen"))];
	    }
	}
	frame = new MainFrame();
    }

    public static void main(String[] args) {

	Environment.mainClass = GEAOran.class;
	Boot.initGraphics();
	Environment.organization = "Municipalidad de San Ram�n de la Nueva Or�n";
	OrganizationInfo.setOrgName("Municipalidad de San Ram�n de la Nueva Or�n");
	OrganizationInfo.setTitle("MUNICIPALIDAD DE\nSAN RAM�N DE LA NUEVA OR�N");
	OrganizationInfo.setShortName("Municipalidad de Or�n");
	OrganizationInfo.setDescription("San Ram�n de la Nueva Or�n - Provincia de Salta");
	OrganizationInfo.setAddress("Belgrano 655 - Or�n - C.P. 4530"); 
	OrganizationInfo.setShortAddress("Belgrano 655");
	OrganizationInfo.setCuit("30-59347057-8");
	OrganizationInfo.setZipCode("4530");
	OrganizationInfo.setLocation("San Ram�n de la Nueva Or�n");
	OrganizationInfo.setProvince("Salta");
	OrganizationInfo.setCountry("Rep�blica Argentina");
	OrganizationInfo.setWebAddress("http://www.oran.gov.ar/");
	OrganizationInfo.setPhoneNumber1("(03878) 421374");
	OrganizationInfo.setPhoneNumber2("(03878) 421975");
	GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
	GraphicsDevice[] devices = env.getScreenDevices();
	new GEAOran(devices);
    }

}
