package org.digitall.extras.ekit;

/** Just am interface for Transformators.

 *

 * @author Robert Gustavsson (robert@lindesign.se)

 */
public interface Transformator {

    public String transform(String word);

}
