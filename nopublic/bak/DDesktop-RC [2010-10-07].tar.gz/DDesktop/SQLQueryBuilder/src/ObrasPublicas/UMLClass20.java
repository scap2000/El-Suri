package ObrasPublicas;

public class UMLClass20 {

    String b2;
    /**
   * Comment here
   * @link aggregationByValue
   * @label UMLAssociation1
   * @associates <{ObrasPublicas.UMLClass30}>
   */
    protected UMLClass30 umlClass30[];

}
