package ObrasPublicas;

public class UMLClass30 {

    String a1;

}
