package ObrasPublicas;

public class UMLClass3 {

    String a1;

}
