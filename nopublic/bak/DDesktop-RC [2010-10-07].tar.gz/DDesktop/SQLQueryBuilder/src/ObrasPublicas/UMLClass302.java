package ObrasPublicas;

public class UMLClass302 {

    String a1;

}
