package ObrasPublicas;

public class UMLClass2 {

    /**
   * Comment here
   * @link aggregation
   * @label UMLAssociation1
   * @associates <{ObrasPublicas.UMLClass3}>
   */
    protected UMLClass3 umlClass30[];
    String b2;

}
